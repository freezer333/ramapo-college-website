package bankdemo;

public enum AccountType {
	Checking, Savings
}
